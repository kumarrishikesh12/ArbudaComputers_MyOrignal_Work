--
-- Database: `arbuda_computer`
--

-- --------------------------------------------------------

--
-- Table structure for table `arbuda_admin`
--

CREATE TABLE `arbuda_admin` (
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `avatar` varchar(200) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `arbuda_admin`
--

INSERT INTO `arbuda_admin` (`id`, `name`, `username`, `email`, `password`, `avatar`, `date`) VALUES
(1, 'Rishikesh', 'Rishii', 'kumarrishikesh12@gmail.com', '123456', 'Rishii.jpg', '2017-07-25 07:23:04');

-- --------------------------------------------------------

--
-- Table structure for table `arbuda_appointment`
--

CREATE TABLE `arbuda_appointment` (
  `id` int(10) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(12) NOT NULL,
  `device_categories` varchar(100) NOT NULL,
  `service` varchar(100) NOT NULL,
  `message` varchar(200) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `arbuda_appointment`
--

INSERT INTO `arbuda_appointment` (`id`, `firstname`, `lastname`, `email`, `phone`, `device_categories`, `service`, `message`, `date`) VALUES
(1, 'Rishii', 'kesh', 'kumarrishikesh12@gmail.com', '8866443689', 'Pc & Mac', 'Pc & Mac Repair', 'I want to repair my desktop.', '2017-07-23 19:07:53'),
(2, 'Max', 'Rocky', 'Max@rocky.com', '8866443689', 'Laptop', 'Laptop Repair', 'Laptop Repair ..', '2017-07-23 23:33:52');

-- --------------------------------------------------------

--
-- Table structure for table `arbuda_associate`
--

CREATE TABLE `arbuda_associate` (
  `id` int(10) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `company_description` varchar(1000) NOT NULL,
  `company_image` varchar(200) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `arbuda_associate`
--

INSERT INTO `arbuda_associate` (`id`, `company_name`, `company_description`, `company_image`, `date`) VALUES
(1, 'INTEL CORPORATION', 'Intel Corporation is an American multinational corporation and technology company headquartered in Santa Clara, California that was founded by Gordon Moore and Robert Noyce.', 'http://localhost/ArbudaComputers/admin/images/upload_associates/associate-01.jpg', '2017-07-24 18:15:24'),
(2, 'ACER INC', 'Acer Inc. is a Taiwanese multinational hardware and electronics corporation specializing in advanced electronics technology and is headquartered in Xizhi, New Taipei City, Taiwan. ', 'http://localhost/ArbudaComputers/admin/images/upload_associates/associate-02.jpg', '2017-07-24 18:18:32'),
(3, 'LG CORPORATION', 'LG Corporation, formerly Deepak-GoldStar, is a South Korean multinational conglomerate corporation. It is the fourth-largest chaebol in South Korea. It is headquartered in the LG Twin Towers building in Yeouido-dong, Yeongdeungpo-gu, Seoul.', 'http://localhost/ArbudaComputers/admin/images/upload_associates/associate-03.jpg', '2017-07-24 18:19:32'),
(4, 'I-BALL', 'iBall is a privately held consumer electronics company headquartered in MIDC Andheri Mumbai, Maharashtra, India, that imports computer peripherals, smartphones and tablets from original equipment manufacturers.', 'http://localhost/ArbudaComputers/admin/images/upload_associates/associate-04.jpg', '2017-07-24 18:20:08'),
(5, 'INTEX', 'Intex Technologies, founded in 1996, is an Indian smartphone, consumer durables and IT accessories manufacturer. Intex is headquartered in New Delhi, India.', 'http://localhost/ArbudaComputers/admin/images/upload_associates/associate-05.jpg', '2017-07-24 18:21:32'),
(6, 'DELL', 'Dell Inc. is a multinational computer technology company based in Round Rock, Texas and, along with Dell EMC, is a subsidiary of Dell Technologies, one of the largest technology companies in the world with 138,000 employees.', 'http://localhost/ArbudaComputers/admin/images/upload_associates/associate-06.jpg', '2017-07-24 18:22:11'),
(7, 'ASUS', 'AsusTek Computer Inc. is a Taiwanese multinational computer and phone hardware and electronics company headquartered in Beitou District, Taipei, Taiwan.', 'http://localhost/ArbudaComputers/admin/images/upload_associates/associate-07.jpg', '2017-07-24 18:22:54'),
(8, 'LENOVO', 'Lenovo Group Ltd. or Lenovo PC International or shortened as Lenovo is a Chinese multinational technology company with headquarters in Beijing, China.', 'http://localhost/ArbudaComputers/admin/images/upload_associates/associate-08.jpg', '2017-07-24 18:23:25'),
(9, 'HP', 'The Hewlett-Packard Company or shortened to Hewlett-Packard was an American multinational information technology company headquartered in Palo Alto, California.', 'http://localhost/ArbudaComputers/admin/images/upload_associates/associate-09.jpg', '2017-07-24 18:24:14'),
(10, 'CANON', 'Canon Inc. is a Japanese multinational corporation specialized in the manufacture of imaging and optical products, including cameras, camcorders, photocopiers, steppers, computer printers and medical equipment.', 'http://localhost/ArbudaComputers/admin/images/upload_associates/associate-10.jpg', '2017-07-24 18:24:45'),
(11, 'LOGITECH', 'Logitech International S.A. is a Swiss global provider of personal computer and mobile accessories, with global headquarters in Lausanne, Switzerland and American headquarters in Newark, California.', 'http://localhost/ArbudaComputers/admin/images/upload_associates/associate-11.jpg', '2017-07-24 18:26:57'),
(12, 'PINNNACLE', 'Pinnacle Systems, Inc. is a California-based American manufacturer of digital video hardware and software for the consumer and broadcast markets. The company was founded in 1986 by Ajay Chopra, Mirek Jiricka and Randall Moore.', 'http://localhost/ArbudaComputers/admin/images/upload_associates/associate-12.jpg', '2017-07-24 18:27:55');

-- --------------------------------------------------------

--
-- Table structure for table `arbuda_career`
--

CREATE TABLE `arbuda_career` (
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(12) NOT NULL,
  `position` varchar(50) NOT NULL,
  `message` varchar(200) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `arbuda_career`
--

INSERT INTO `arbuda_career` (`id`, `name`, `email`, `phone`, `position`, `message`, `date`) VALUES
(1, 'Rishii', 'kumarrishikesh12@gmail.com', '8866443689', 'The Technician', 'I have  6 month Experience in Laravel Framework', '2017-07-23 16:45:38'),
(2, 'Max', 'Max@carrer.com', '9898123654', 'Smartphone Technician', 'I am SmartPhone Technician . and I have 1 Year Experience in Smart Phone Technician.', '2017-07-23 16:47:46');

-- --------------------------------------------------------

--
-- Table structure for table `arbuda_contact`
--

CREATE TABLE `arbuda_contact` (
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `subject` varchar(100) NOT NULL,
  `message` varchar(200) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `arbuda_contact`
--

INSERT INTO `arbuda_contact` (`id`, `name`, `email`, `subject`, `message`, `date`) VALUES
(1, 'Rishii', 'kumarrishikesh12@gmail.com', 'Inquiry Related To Computer', 'I want to buy an Desktop Pc.', '2017-07-23 16:26:02'),
(2, 'Max', 'Max@carrer.com', 'I want to Work In Arbuda Computer as SmartPhone Technician', 'Looking For Job For SmartPhone Technician .', '2017-07-23 16:49:12');

-- --------------------------------------------------------

--
-- Table structure for table `arbuda_feedback`
--

CREATE TABLE `arbuda_feedback` (
  `id` int(10) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(12) NOT NULL,
  `date_visited` varchar(100) NOT NULL,
  `visited_location` varchar(100) NOT NULL,
  `recommed` varchar(100) NOT NULL,
  `message` varchar(200) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `arbuda_feedback`
--

INSERT INTO `arbuda_feedback` (`id`, `firstname`, `lastname`, `email`, `phone`, `date_visited`, `visited_location`, `recommed`, `message`, `date`) VALUES
(1, 'Rishii', 'kesh', 'kumarrishikesh12@gmail.com', '8866443689', '12-07-2017', 'Laptop Repair', 'fabulous', 'Hiiiiii', '2017-07-23 18:31:33'),
(2, 'Rishii', 'kesh', 'kumarrishikesh12@gmail.com', '8866443689', '10-08-2017', 'Laptop Repair', 'fabulous', 'Hiiiiii', '2017-07-23 18:49:32'),
(3, 'Rishii', 'kesh', 'kumarrishikesh12@gmail.com', '8866443689', '15-07-2017', 'Laptop Repair', 'fabulous', 'Hiiiiii', '2017-07-23 18:49:51'),
(4, 'Rishii', 'max', 'adad@adad.com', '9898123654', '12-07-2017', 'Console Repair', 'very-likely', 'dadadadasda', '2017-07-23 18:39:31');

-- --------------------------------------------------------

--
-- Table structure for table `arbuda_gallery`
--

CREATE TABLE `arbuda_gallery` (
  `id` int(10) NOT NULL,
  `categories_name` varchar(100) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `arbuda_gallery`
--

INSERT INTO `arbuda_gallery` (`id`, `categories_name`, `photo`, `date`) VALUES
(1, 'Pc & Mac', 'http://localhost/ArbudaComputers/admin/images/upload_gallery/Mac Pc - 1.gif', '2017-07-24 19:43:09'),
(2, 'Pc & Mac', 'http://localhost/ArbudaComputers/admin/images/upload_gallery/Mac Pc - 2.jpg', '2017-07-24 19:44:08'),
(3, 'Laptop', 'http://localhost/ArbudaComputers/admin/images/upload_gallery/Mac Laptop - 1.jpg', '2017-07-24 19:44:51'),
(4, 'Laptop', 'http://localhost/ArbudaComputers/admin/images/upload_gallery/Hp Laptop - 2.jpg', '2017-07-24 19:45:04'),
(5, 'Laptop', 'http://localhost/ArbudaComputers/admin/images/upload_gallery/Sony Laptop - 3.JPG', '2017-07-24 19:45:14'),
(6, 'Laptop', 'http://localhost/ArbudaComputers/admin/images/upload_gallery/Lenovo Laptop - 4.jpg', '2017-07-24 19:45:24'),
(7, 'Tablet', 'http://localhost/ArbudaComputers/admin/images/upload_gallery/Sony Tablet - 1.jpg', '2017-07-24 19:45:38'),
(8, 'Tablet', 'http://localhost/ArbudaComputers/admin/images/upload_gallery/Hp Tablet - 2.jpeg', '2017-07-24 19:45:49'),
(9, 'Tablet', 'http://localhost/ArbudaComputers/admin/images/upload_gallery/Lenovo Tablet - 3.jpg', '2017-07-24 19:46:13'),
(10, 'Printer', 'http://localhost/ArbudaComputers/admin/images/upload_gallery/Hp Printer - 1.jpg', '2017-07-24 19:46:38'),
(11, 'Printer', 'http://localhost/ArbudaComputers/admin/images/upload_gallery/Hp Printer - 2.jpg', '2017-07-24 19:46:47'),
(12, 'Camera', 'http://localhost/ArbudaComputers/admin/images/upload_gallery/Sony Camera - 1.jpg', '2017-07-24 19:47:18'),
(13, 'Camera', 'http://localhost/ArbudaComputers/admin/images/upload_gallery/Sony Camera - 2.jpg', '2017-07-24 19:47:26'),
(14, 'Camera', 'http://localhost/ArbudaComputers/admin/images/upload_gallery/Nikon Camera - 3.jpg', '2017-07-24 19:47:35'),
(15, 'Camera', 'http://localhost/ArbudaComputers/admin/images/upload_gallery/Canon Camera - 4.jpg', '2017-07-24 19:47:52'),
(16, 'Data Recovery', 'http://localhost/ArbudaComputers/admin/images/upload_gallery/Photo-Recovery.jpg', '2017-07-25 09:55:54'),
(17, 'Data Recovery', 'http://localhost/ArbudaComputers/admin/images/upload_gallery/Photo-Recovery.jpg', '2017-07-25 09:56:20'),
(18, 'Data Recovery', 'http://localhost/ArbudaComputers/admin/images/upload_gallery/Photo-Recovery.jpg', '2017-07-24 19:49:07'),
(19, 'Data Recovery', 'http://localhost/ArbudaComputers/admin/images/upload_gallery/ios-data-recovery.jpg', '2017-07-24 19:49:22');

-- --------------------------------------------------------

--
-- Table structure for table `arbuda_ouraward`
--

CREATE TABLE `arbuda_ouraward` (
  `id` int(10) NOT NULL,
  `award_name` varchar(100) NOT NULL,
  `year` varchar(100) NOT NULL,
  `avatar` varchar(200) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `arbuda_ouraward`
--

INSERT INTO `arbuda_ouraward` (`id`, `award_name`, `year`, `avatar`, `date`) VALUES
(1, 'Warren Lowder', '2000', 'http://localhost/ArbudaComputers/admin/images/upload_award/Warren Lowder.jpg', '2017-07-24 16:58:01'),
(2, 'Craig Easterling', '2010', 'http://localhost/ArbudaComputers/admin/images/upload_award/Craig Easterling.jpg', '2017-07-24 17:01:03'),
(3, 'Glenn Harris', '2000', 'http://localhost/ArbudaComputers/admin/images/upload_award/Glenn Harris.jpg', '2017-07-24 17:00:41'),
(4, 'Amy Hagen', '2000', 'http://localhost/ArbudaComputers/admin/images/upload_award/Amy Hagen.jpg', '2017-07-24 17:01:37');

-- --------------------------------------------------------

--
-- Table structure for table `arbuda_ourteam`
--

CREATE TABLE `arbuda_ourteam` (
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `avatar` varchar(200) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `arbuda_ourteam`
--

INSERT INTO `arbuda_ourteam` (`id`, `name`, `designation`, `avatar`, `date`) VALUES
(1, 'Warren Lowder', 'OWNER', 'http://localhost/ArbudaComputers/admin/images/upload_team/Warren Lowder.jpg', '2017-07-24 17:33:45'),
(2, 'Craig Easterling', 'ACCOUNT RECEVABLE', 'http://localhost/ArbudaComputers/admin/images/upload_team/Craig Easterling.jpg', '2017-07-24 17:35:16'),
(3, 'Glenn Harris', 'TECHNICAL SUPPORT', 'http://localhost/ArbudaComputers/admin/images/upload_team/Glenn Harris.jpg', '2017-07-24 17:36:09'),
(4, 'Amy Hagen', 'SERVICE MANAGER', 'http://localhost/ArbudaComputers/admin/images/upload_team/Amy Hagen.jpg', '2017-07-24 17:37:08'),
(5, 'Irwin William', 'MARKETING ASSOCIATE', 'http://localhost/ArbudaComputers/admin/images/upload_team/Irwin William.jpg', '2017-07-24 17:37:40'),
(6, 'James Ward', 'SALES ASSOCIATES', 'http://localhost/ArbudaComputers/admin/images/upload_team/James Ward.jpg', '2017-07-24 17:38:05'),
(7, 'John Camacho', 'SERVICE MANAGER', 'http://localhost/ArbudaComputers/admin/images/upload_team/John Camacho.jpg', '2017-07-24 17:38:48'),
(8, 'Brian Shah', 'SERVICE MANAGER', 'http://localhost/ArbudaComputers/admin/images/upload_team/Brian Shah.jpg', '2017-07-24 17:39:25');

-- --------------------------------------------------------

--
-- Table structure for table `arbuda_product`
--

CREATE TABLE `arbuda_product` (
  `id` int(10) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `product_image` varchar(200) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `arbuda_product`
--

INSERT INTO `arbuda_product` (`id`, `product_name`, `company_name`, `product_image`, `date`) VALUES
(1, 'Computer', 'Dell, HP', 'http://localhost/ArbudaComputers/admin/images/upload_product/product-1.jpg', '2017-07-24 18:52:57'),
(2, 'Laptop', 'Lenovo, Sony, Accer, Dell, HP', 'http://localhost/ArbudaComputers/admin/images/upload_product/product-2.jpg', '2017-07-24 18:54:54'),
(3, 'Scanner', 'Sony, Accer, HP, Samsung', 'http://localhost/ArbudaComputers/admin/images/upload_product/product-3.jpg', '2017-07-24 18:56:40'),
(4, 'CPU', 'Samsung, Accer, Dell, HP', 'http://localhost/ArbudaComputers/admin/images/upload_product/product-4.jpg', '2017-07-24 18:58:03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `arbuda_admin`
--
ALTER TABLE `arbuda_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `arbuda_appointment`
--
ALTER TABLE `arbuda_appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `arbuda_associate`
--
ALTER TABLE `arbuda_associate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `arbuda_career`
--
ALTER TABLE `arbuda_career`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `arbuda_contact`
--
ALTER TABLE `arbuda_contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `arbuda_feedback`
--
ALTER TABLE `arbuda_feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `arbuda_gallery`
--
ALTER TABLE `arbuda_gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `arbuda_ouraward`
--
ALTER TABLE `arbuda_ouraward`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `arbuda_ourteam`
--
ALTER TABLE `arbuda_ourteam`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `arbuda_product`
--
ALTER TABLE `arbuda_product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `arbuda_admin`
--
ALTER TABLE `arbuda_admin`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `arbuda_appointment`
--
ALTER TABLE `arbuda_appointment`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `arbuda_associate`
--
ALTER TABLE `arbuda_associate`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `arbuda_career`
--
ALTER TABLE `arbuda_career`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `arbuda_contact`
--
ALTER TABLE `arbuda_contact`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `arbuda_feedback`
--
ALTER TABLE `arbuda_feedback`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `arbuda_gallery`
--
ALTER TABLE `arbuda_gallery`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `arbuda_ouraward`
--
ALTER TABLE `arbuda_ouraward`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `arbuda_ourteam`
--
ALTER TABLE `arbuda_ourteam`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `arbuda_product`
--
ALTER TABLE `arbuda_product`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
